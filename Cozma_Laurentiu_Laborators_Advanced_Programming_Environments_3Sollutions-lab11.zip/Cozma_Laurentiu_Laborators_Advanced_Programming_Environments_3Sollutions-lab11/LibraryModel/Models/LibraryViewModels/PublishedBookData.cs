﻿namespace LibraryModel.Models.LibraryViewModels
{
    public class PublishedBookData
    {
        public int BookId { get; set; }
        public string Title { get; set; }
        public bool IsPublished { get; set; }
    }
}
