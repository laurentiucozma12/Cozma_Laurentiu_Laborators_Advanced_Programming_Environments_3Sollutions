using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Cozma_Laurentiu_Lab2.Views.Home
{
    public class ChatModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
